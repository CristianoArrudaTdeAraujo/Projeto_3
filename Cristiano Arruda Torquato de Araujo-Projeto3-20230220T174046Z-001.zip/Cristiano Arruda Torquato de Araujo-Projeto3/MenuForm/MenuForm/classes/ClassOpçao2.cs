﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuForm.classes
{
    class ClassOpçao2
    {
        public int mult(int num1, int num2)
        {
            int res;
            res = num1 * num2;
            return res;
        }

        
    }
}
