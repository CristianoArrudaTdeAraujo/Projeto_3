﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MenuForm.classes
{
    class ClassOpçao1
    {
        public string Saudar (String nome)
        {
            String saudacao;
            saudacao = "Bom dia "+nome+", como vai você hoje??";
            return saudacao;
        }

    }
}
